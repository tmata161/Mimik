#include "script_injection.h"

#define TYPE_DELAY 25 //fixed length delay between key presses
#define strokelength 6

void key_release();
void key_press(uint8_t key);

// a function that will check each character from the dictionary and return its equivalent hid command
uint8_t get_key_code(char *keycharacters){
    int i=0;
    for(i; i<key_length; i++){
        if(strcmp(keycharacters, key_codes[i].letter)==0)
            break;
    }
    if(i<key_length)
        return key_codes[i].key;
    else return 0x00;//getextracodes(keycharacters);
}

/*Instruction code->
    0: REM
    1: PRESS
    2: TYPE
    3: DELAY
*/
void script_injection(int ins_code, char* instruction){
    //tud_init(0);
    tusb_init();

    board_delay(1000);
    if (board_init_after_tusb) 
    {
        board_init_after_tusb();
    }
    // tinyusb will run as device mode
    tud_task();
    //start key injection
    //check if device is suspended
    while(tud_suspended()) tud_remote_wakeup();

    if(tud_hid_ready())
    {
        switch(ins_code){

            //press
            case 1:
                key_press(get_key_code(instruction));
                break;

            //type
            case 2:
                for(int i=0; i<strlen(instruction); i++)
                {
                    char tmp[1];
                    tmp[0]=instruction[i];
                    key_press(get_key_code(tmp));
                }
                break;

            //delay
            case 3:
                int num = atoi(instruction);
                board_delay(num*1000); //for milliseconds
                break;

            default:
                printf("Unknown instruction\n");
                break;
            }
        }
}


//!--------------------------------------------------------------------+
//!                 Keystroke Injection Code
//!--------------------------------------------------------------------+


void key_press(uint8_t key){ //index is the index of myLexer object
    uint8_t keystrokes[strokelength]={0};
    keystrokes[0] = key;
    tud_hid_keyboard_report(REPORT_ID_KEYBOARD, 0, keystrokes);
    board_delay(TYPE_DELAY);
    key_release();
}

void key_release(){
  // report null character to host device
  tud_hid_keyboard_report(REPORT_ID_KEYBOARD, 0, NULL);
}

//!--------------------------------------------------------------------+
//!                             TUD Code
//!--------------------------------------------------------------------+
// Invoked when sent REPORT successfully to host
// Application can use this to send the next report
// Note: For composite reports, report[0] is report ID
void tud_hid_report_complete_cb(uint8_t instance, uint8_t const* report, uint16_t len)
{return;}

// Invoked when received GET_REPORT control request
// Application must fill buffer report's content and return its length.
// Return zero will cause the stack to STALL request
uint16_t tud_hid_get_report_cb(uint8_t instance, uint8_t report_id, hid_report_type_t report_type, uint8_t* buffer, uint16_t reqlen)
{   printf("tud_hid_get_report_cb\n");
    return 0;
}

// Invoked when received SET_REPORT control request or
// received data on OUT endpoint ( Report ID = 0, Type = 0 )
void tud_hid_set_report_cb(uint8_t instance, uint8_t report_id, hid_report_type_t report_type, uint8_t const* buffer, uint16_t bufsize)
{}
//lets check callback function
void tud_mount_cb(void){}
// Invoked when device is unmounted
void tud_umount_cb(void){}
// Invoked when usb bus is suspended
// remote_wakeup_en : if host allow us  to perform remote wakeup
// Within 7ms, device must draw an average of current less than 2.5 mA from bus
void tud_suspend_cb(bool remote_wakeup_en){}
// Invoked when usb bus is resumed
void tud_resume_cb(){return;}